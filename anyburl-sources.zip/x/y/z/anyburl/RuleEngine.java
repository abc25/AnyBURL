package x.y.z.anyburl;


import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.AbstractMap.SimpleImmutableEntry;
import java.util.stream.Collectors;

import x.y.z.anyburl.data.*;
import x.y.z.anyburl.structure.*;

public class RuleEngine {

	public static int COMBINATION_RULE_ID = 1;
	private final static double EPSILON = 0.0001;
	
	
	public static void applyRulesARX(LinkedList<Rule> rules, TripleSet testSet, TripleSet trainingSet, TripleSet validationSet, int k, PrintWriter resultsWriter) {
		System.out.println("* applying rules");
		// HashMap<String, HashSet<Rule>> relation2Rules = createRuleIndex(rules);

		HashMap<String, ArrayList<Rule>> relation2Rules = createOrderedRuleIndex(rules);
		
		System.out.println("* set up index structure covering rules for " + relation2Rules.size() + " different relations");
		TripleSet filterSet = new TripleSet();
		// TODO
		filterSet.addTripleSet(trainingSet);
		filterSet.addTripleSet(validationSet);
		filterSet.addTripleSet(testSet);
		System.out.println("* constructed filter set with " + filterSet.getTriples().size() + " triples");
		if (filterSet.getTriples().size() == 0) {
			System.err.println("WARNING: using empty filter set!");
		}
		// prepare the data structures used a s cache for question that are reoccuring
		HashMap<SimpleImmutableEntry<String, String>, LinkedHashMap<String, Double>> headCandidateCache = new HashMap<SimpleImmutableEntry<String, String>, LinkedHashMap<String, Double>>();
		HashMap<SimpleImmutableEntry<String, String>, LinkedHashMap<String, Double>> tailCandidateCache = new HashMap<SimpleImmutableEntry<String, String>, LinkedHashMap<String, Double>>();
		// start iterating over the test cases
		int counter = 0;
		long startTime = System.currentTimeMillis();
		long currentTime = 0;
		
		
		ScoreTree.LOWER_BOUND = k;
		ScoreTree.UPPER_BOUND = ScoreTree.LOWER_BOUND;
		ScoreTree.EPSILON = EPSILON;
		
		for (Triple triple : testSet.getTriples()) {
			// System.out.println("* (#" + counter + ") trying to guess the tail/head of " + triple.toString());
			if (counter % 50 == 0) {
				System.out.println("* (#" + counter + ") trying to guess the tail/head of " + triple.toString());
				currentTime = System.currentTimeMillis();
				System.err.println("Elapsed (s) = " + ((currentTime - startTime) / 1000));
				// 8 seconds per 1000 triples
			}
			// if (counter == 99) System.exit(1);
			counter++;
			String relation = triple.getRelation();
			String head = triple.getHead();
			String tail = triple.getTail();
			// not sorted, everything including stuff that should be filtered 
			//out HashMap<String, Double> tailCandidates2Probabilities = new HashMap<String, Double>();
			//out HashMap<String, Double> headCandidates2Probabilities = new HashMap<String, Double>();
			// sorted, filtered and reduced to the top k
			// LinkedHashMap<String, Double> kTailCandidates = new LinkedHashMap<String, Double>();
			// LinkedHashMap<String, Double> kHeadCandidates = new LinkedHashMap<String, Double>();
			
			SimpleImmutableEntry<String, String> tQuestion = new SimpleImmutableEntry<String, String>(triple.getRelation(), triple.getHead());
			SimpleImmutableEntry<String, String> hQuestion = new SimpleImmutableEntry<String, String>(triple.getRelation(), triple.getTail());
			
			// if (tailCandidateCache.containsKey(tQuestion)) tailCandidates2Probabilities = tailCandidateCache.get(tQuestion);
			// if (headCandidateCache.containsKey(hQuestion)) headCandidates2Probabilities = headCandidateCache.get(hQuestion);
			
			
			ScoreTree kTailTree = new ScoreTree();
			ScoreTree kHeadTree = new ScoreTree();

			
			
			if (relation2Rules.containsKey(relation)) {
				ArrayList<Rule> relevantRules = relation2Rules.get(relation);
				if (!tailCandidateCache.containsKey(tQuestion)) {
					for (Rule rule : relevantRules) {
						if (!kTailTree.fine()) {
							HashSet<String> tailCandidates = rule.computeTailResults(head, trainingSet);
							HashSet<String> fTailCandidates = getFilteredEntities(filterSet, testSet, triple, tailCandidates, true);
							kTailTree.addValues(rule.getAppliedConfidence(), fTailCandidates);
						}
						else {
							break;
						}
					}
				}
				if (!headCandidateCache.containsKey(hQuestion)) {
					for (Rule rule : relevantRules) {
						
						if (!kHeadTree.fine()) {
							HashSet<String> headCandidates = rule.computeHeadResults(tail, trainingSet);
							HashSet<String> fHeadCandidates = getFilteredEntities(filterSet, testSet, triple, headCandidates, false);
							kHeadTree.addValues(rule.getAppliedConfidence(), fHeadCandidates);
						}
						else {
							break;
						}
						
						
					}
				}	
			}
			//show(kTailCandidates, "k tails after adding epsilon");
			// show(kHeadCandidates, "k heads after adding epsilon");
			
			
			LinkedHashMap<String, Double> kTailCandidates = new LinkedHashMap<String, Double>();
			LinkedHashMap<String, Double> kHeadCandidates = new LinkedHashMap<String, Double>();
			
			kTailTree.getAsLinkedList(kTailCandidates);
			kHeadTree.getAsLinkedList(kHeadCandidates);
			
			/*
			if ((counter-1) % 10 == 0) {
				System.out.println("Tail Tree:\n" + kTailTree);
				System.out.println("Head Tree:\n" + kHeadTree);
				
			}
			*/

			
			// final sorting
			kTailCandidates = sortByValue(kTailCandidates);
			kHeadCandidates = sortByValue(kHeadCandidates);
			
			// show(kTailCandidates, "k tails after sorting");
			// show(kHeadCandidates, "k heads after sorting");
			
			// update cache and write results

			writeTopKCandidates(triple, testSet, kHeadCandidates, kTailCandidates, resultsWriter, k);
			
			// processTopKCandidates(testSet, triple, tailCandidates2Probabilities, headCandidates2Probabilities, filterSet, k, resultsWriter, kTailCandidates, kHeadCandidates);
	
			// if (!headCandidateCache.containsKey(hQuestion)) headCandidateCache.put(hQuestion, kHeadCandidates);
			// if (!tailCandidateCache.containsKey(tQuestion)) tailCandidateCache.put(tQuestion, kTailCandidates);
			// if (counter % 100 == 0) System.out.println("HCache=" + headCandidateCache.size() + " TCache=" + tailCandidateCache.size());
		}
		System.out.println("* done with rule application");

	}
	
	private static void show(LinkedHashMap<String, Double> kCandidates, String headline) {
		System.out.println("*** " + headline + " ***");
		for (String candidate : kCandidates.keySet()) {
			double conf = kCandidates.get(candidate);
			System.out.println(conf + " = " + candidate);
		}
	}

	private static HashMap<String, HashSet<Rule>> createRuleIndex(List<Rule> rules) {
		
		int counterL1C = 0;
		int counterL2C = 0;
		int counterL1AC = 0;
		int counterL1AN = 0;
		int counterOther = 0;
		
		HashMap<String, HashSet<Rule>> relation2Rules = new HashMap<String, HashSet<Rule>>();
		for (Rule rule : rules) {
			
			/*
			
			if (rule.isXYRule()) {
				if (rule.bodysize() == 1)  counterL1C++;
				if (rule.bodysize() == 2)  counterL2C++;
			}
			else {
				
				if (rule.bodysize() == 1)  {
					if (rule.hasConstantInBody()) counterL1AC++;
					else counterL1AN++;
				}
				else {
					if (rule.hasConstantInBody()) continue;
				}	
			}
			*/
			
			String relation = rule.getTargetRelation();
			if (!relation2Rules.containsKey(relation)) relation2Rules.put(relation, new HashSet<Rule>());
			relation2Rules.get(relation).add(rule);
			
			
		}
		// System.out.println("L1C=" + counterL1C + " L2C=" + counterL2C + " L1AC=" + counterL1AC + " L1AN=" + counterL1AN + " OTHER=" + counterOther);
		return relation2Rules;
	}
	
	
	private static HashMap<String, ArrayList<Rule>> createOrderedRuleIndex(LinkedList<Rule> rules) {
		HashMap<String, ArrayList<Rule>> relation2Rules = new HashMap<String, ArrayList<Rule>>();
		long l = 0;
		while (rules.size() > 0) {
			Rule rule = rules.poll();
			// Rule rule = rules.remove(rules.size()-1);
			String relation = rule.getTargetRelation();
			
			if (!relation2Rules.containsKey(relation)) {
				relation2Rules.put(relation, new ArrayList<Rule>());
			}
			relation2Rules.get(relation).add(rule);	
			l++;
		}
		
		for (String relation : relation2Rules.keySet()) {
			relation2Rules.get(relation).trimToSize();
			relation2Rules.get(relation).sort(new RuleConfidenceComparator());
		}
		return relation2Rules;
	}


	private static void updateCandidateProbabailities(Rule rule, boolean tailNotHead, String candidate, HashMap<String, Double> candidates2Probabilities) {
		double prob = rule.getAppliedConfidence();
		if (!candidates2Probabilities.containsKey(candidate)) candidates2Probabilities.put(candidate, prob);
		else {
			double previousProb = candidates2Probabilities.get(candidate);
			double newProb = combineProbability(prob, previousProb);
			candidates2Probabilities.put(candidate, newProb);
		}
	}
	
	
	private static LinkedHashMapK getFilteredCandidates(TripleSet filterSet, TripleSet testSet, Triple t, HashMap<String, Double> candidates, boolean tailNotHead) {
		// LinkedHashMap<String, Double> candidatesSorted = sortByValue(candidates);
		LinkedHashMap<String, Double> kCandidates = new LinkedHashMap<String, Double>();
		int i = 0;
		for (Entry<String, Double> entry : candidates.entrySet()) {
			if (!tailNotHead) {
				if (!filterSet.isTrue(entry.getKey(), t.getRelation(), t.getTail())) {
					kCandidates.put(entry.getKey(), entry.getValue());
					i++;
				}
				if (testSet.isTrue(entry.getKey(), t.getRelation(), t.getTail())) {
					kCandidates.put(entry.getKey(), entry.getValue());
				}
			}
			if (tailNotHead) {
				if (!filterSet.isTrue(t.getHead(), t.getRelation(), entry.getKey())) {
					kCandidates.put(entry.getKey(), entry.getValue());
					i++;
				}
				if (testSet.isTrue(t.getHead(), t.getRelation(), entry.getKey())) {
					kCandidates.put(entry.getKey(), entry.getValue());
				}
			}
		}
		return (new LinkedHashMapK(kCandidates, i));
	}
	
	
	
	private static HashSet<String> getFilteredEntities(TripleSet filterSet, TripleSet testSet, Triple t, HashSet<String> candidateEntities, boolean tailNotHead) {
		// LinkedHashMap<String, Double> candidatesSorted = sortByValue(candidates);
		HashSet<String> filteredEntities = new HashSet<String>();
		for (String entity : candidateEntities) {
			if (!tailNotHead) {
				if (!filterSet.isTrue(entity, t.getRelation(), t.getTail())) {
					filteredEntities.add(entity);
				}
				
				if (testSet.isTrue(entity, t.getRelation(), t.getTail())) {
					// TAKE CARE, remove to reactivate the possibility of storing previous results
					if (entity.equals(t.getHead())) filteredEntities.add(entity);
				}
				
			}
			if (tailNotHead) {
				if (!filterSet.isTrue(t.getHead(), t.getRelation(), entity)) {
					filteredEntities.add(entity);
				}
				if (testSet.isTrue(t.getHead(), t.getRelation(), entity)) {
					// TAKE CARE, remove to reactivate the possibility of storing previous results
					if (entity.equals(t.getTail())) filteredEntities.add(entity);
				}
			}
		}
		return filteredEntities;
	}
	
	private static void writeTopKCandidates(Triple t, TripleSet testSet, LinkedHashMap<String, Double> kHeadCandidates, LinkedHashMap<String, Double> kTailCandidates, PrintWriter writer, int k) {
		writer.println(t);
		int i = 0;
		writer.print("Heads: ");
		for (Entry<String, Double> entry : kHeadCandidates.entrySet()) {
			if (t.getHead().equals(entry.getKey()) || !testSet.isTrue(entry.getKey(), t.getRelation(), t.getTail())) {
				writer.print(entry.getKey() + "\t" + entry.getValue() + "\t");
				i++;
			}
			if (i == k) break;
		}
		writer.println();
		i = 0;
		writer.print("Tails: ");
		for (Entry<String, Double> entry : kTailCandidates.entrySet()) {
			if (t.getTail().equals(entry.getKey()) || !testSet.isTrue(t.getHead(), t.getRelation(), entry.getKey())) {
				writer.print(entry.getKey() + "\t" + entry.getValue() + "\t");
				i++;
			}
			if (i == k) break;
		}
		writer.println();
		writer.flush();
	}
	
	/*
	private static void processTopKCandidates(TripleSet testSet, Triple t, HashMap<String, Double> tailCandidates, HashMap<String, Double> headCandidates, TripleSet filterSet, int k, PrintWriter writer, HashMap<String, Double> kTailCandidates, HashMap<String, Double> kHeadCandidates) {
		LinkedHashMap<String, Double> tailCandidatesSorted = sortByValue(tailCandidates);
		LinkedHashMap<String, Double> headCandidatesSorted = sortByValue(headCandidates);
		writer.println(t);
		writer.print("Heads: ");
		int i = 0;
		for (Entry<String, Double> entry : headCandidatesSorted.entrySet()) {
			if (i < k) {
				if (!filterSet.isTrue(entry.getKey(), t.getRelation(), t.getTail()) || t.getHead().equals(entry.getKey())) {
					writer.print(entry.getKey() + "\t" + entry.getValue() + "\t");
					kHeadCandidates.put(entry.getKey(), entry.getValue());
					i++;
				}
				if (testSet.isTrue(entry.getKey(), t.getRelation(), t.getTail())) {
					kHeadCandidates.put(entry.getKey(), entry.getValue());
				}
			}
		}
		writer.println();
		writer.print("Tails: ");
		int j = 0;
		for (Entry<String, Double> entry : tailCandidatesSorted.entrySet()) {
			if (j < k) {
				if (!filterSet.isTrue(t.getHead(), t.getRelation(), entry.getKey())
						|| t.getTail().equals(entry.getKey())) {
					writer.print(entry.getKey() + "\t" + entry.getValue() + "\t");
					kTailCandidates.put(entry.getKey(), entry.getValue());
					j++;
				}
				if (testSet.isTrue(t.getHead(), t.getRelation(), entry.getKey())) {
					kTailCandidates.put(entry.getKey(), entry.getValue());
				}
			}
		}
		writer.println();
		writer.flush();
	}
	*/

	
	private static double combineProbability(double prob, double previousProb) {
		double newProb;
		switch (COMBINATION_RULE_ID) {
		case 1: // multiplication
			newProb = 1.0 - ((1.0 - previousProb) * (1.0 - prob));
			break;
		case 2: // maxplus
			newProb = Math.max(previousProb, prob) + EPSILON;
			break;
		case 3: // max
		default:
			newProb = Math.max(previousProb, prob);
			break;
		}
		return newProb;
	}
	

	
	public static <K, V extends Comparable<? super V>> LinkedHashMap<K, V> sortByValue(Map<K, V> map) {
		return map.entrySet().stream().sorted(Map.Entry.comparingByValue(Collections.reverseOrder()))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
	}
	

	private static String f(double d) {
		DecimalFormat df = new DecimalFormat("0.000");
		return df.format(d);
	}

	
}
