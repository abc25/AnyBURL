package x.y.z.anyburl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;

import x.y.z.anyburl.data.TripleSet;
import x.y.z.anyburl.io.IOHelper;
import x.y.z.anyburl.io.RuleReader;
import x.y.z.anyburl.structure.Rule;
import x.y.z.anyburl.structure.RuleFilter;

public class Apply {
		
	
	private static String CONFIG_FILE = "config-apply.properties";
	
	
	/**
	 * Defines the prediction type which also influences the usage of the other parameters. 
	 * Possible values are currently aRx and xRy.
	 */
	public static String PREDICTION_TYPE = "aRx";
	
	/**
	 * Path to the file that contains the triple set used for learning the rules.
	 */
	public static String PATH_TRAINING = "";
	
	
	/**
	 * Path to the file that contains the triple set used for to test the rules.
	 */
	public static String PATH_TEST = "";
	
	/**
	 * Path to the file that contains the triple set used validation purpose (e.g. learning hyper parameter).
	 */
	public static String PATH_VALID = "";
	
	/**
	 * Path to the output file where the predictions are stored.
	 */
	public static String PATH_OUTPUT = "";
	
	/**
	 * Path to the rule file.
	 */
	public static String PATH_RULES = "";
	
	/**
	 * The top-k results that are after filtering kept in the results. 
	 */
	public static int TOP_K_OUTPUT = 10;	
	
	/**
	 * The number of negative examples for which we assume that they exist, however, we have not seen them. Rules with high coverage are favored the higher the chosen number. 
	 */
	public static int UNSEEN_NEGATIVE_EXAMPLES = 100;	
	
	
	/**
	 * Returns only results for head or tail computation if the results set has less elements than this bound.
	 * The idea is that any results set which has more elements is anyhow not useful for a top-k ranking. 
	 * Should be set to a value thats higher than the k of the requested top-k (however, the higher the value,
	 * the more runtime is required)
	 */
	public static int DISCRIMINATION_BOUND = 1000;	
	
	
	/**
	* Number of maximal attempts to create body grounding. Every partial body grounding is counted.
	*/
	public static int TRIAL_SIZE = 100000;
	
	
	/**
	* Defines how to combine probabilities that come from different rules
	* Possible values are: multiplication, maxplus (which adds for each further rule a very small bonus), max
	*/
	public static String COMBINATION_RULE = "maxplus";
	
	
	/**
	 * Filter the rule set prior to applying it. Removes redundant rules which do not have any impact (or no desired impact). 
	 */
	public static boolean FILTER = true;	
	
	
	public static void main(String[] args) throws IOException {
		
		if (args.length == 1) {
			CONFIG_FILE = args[0];
			System.out.println("reading params from file " + CONFIG_FILE);
		}
		
		Rule.applicationMode();
		Properties prop = new Properties();
		InputStream input = null;
		try {
			input = new FileInputStream(CONFIG_FILE);
			prop.load(input);
			PREDICTION_TYPE = IOHelper.getProperty(prop, "PREDICTION_TYPE",PREDICTION_TYPE);
			if (PREDICTION_TYPE.equals("aRx")) {
				PATH_TRAINING = IOHelper.getProperty(prop, "PATH_TRAINING",PATH_TRAINING);
				PATH_TEST = IOHelper.getProperty(prop, "PATH_TEST", PATH_TEST);
				PATH_VALID = IOHelper.getProperty(prop, "PATH_VALID",PATH_VALID);
				PATH_OUTPUT = IOHelper.getProperty(prop, "PATH_OUTPUT", PATH_OUTPUT);
				PATH_RULES = IOHelper.getProperty(prop, "PATH_RULES", PATH_RULES);
				TOP_K_OUTPUT = IOHelper.getProperty(prop, "TOP_K_OUTPUT", TOP_K_OUTPUT);
				UNSEEN_NEGATIVE_EXAMPLES = IOHelper.getProperty(prop, "UNSEEN_NEGATIVE_EXAMPLES", UNSEEN_NEGATIVE_EXAMPLES);
				DISCRIMINATION_BOUND = IOHelper.getProperty(prop, "DISCRIMINATION_BOUND",  DISCRIMINATION_BOUND);
				TRIAL_SIZE = IOHelper.getProperty(prop, "TRIAL_SIZE",  TRIAL_SIZE);
				FILTER = IOHelper.getProperty(prop, "FILTER", FILTER);
				COMBINATION_RULE = IOHelper.getProperty(prop, "COMBINATION_RULE", COMBINATION_RULE);
				if (COMBINATION_RULE.equals("multiplication")) RuleEngine.COMBINATION_RULE_ID = 1;
				if (COMBINATION_RULE.equals("maxplus")) RuleEngine.COMBINATION_RULE_ID = 2;
				if (COMBINATION_RULE.equals("max")) RuleEngine.COMBINATION_RULE_ID = 3;
			}
			/*
			else if (PREDICTION_TYPE.equals("xRy")) {
				TRESHOLD_FUNCTIONAL = IOHelper.getProperty(prop, "TRESHOLD_FUNCTIONAL", TRESHOLD_FUNCTIONAL);
				System.out.println("TF: " + TRESHOLD_FUNCTIONAL);
				PATH_TRAINING = IOHelper.getProperty(prop, "PATH_TRAINING",PATH_TRAINING);
				PATH_TEST = IOHelper.getProperty(prop, "PATH_TEST", PATH_TEST);
				PATH_VALID = IOHelper.getProperty(prop, "PATH_VALID",PATH_VALID);
				PATH_OUTPUT = IOHelper.getProperty(prop, "PATH_OUTPUT", PATH_OUTPUT);
				PATH_RULES = IOHelper.getProperty(prop, "PATH_RULES", PATH_RULES);
				TOP_K_OUTPUT = IOHelper.getProperty(prop, "TOP_K_OUTPUT", TOP_K_OUTPUT);
				COMBINATION_RULE = IOHelper.getProperty(prop, "COMBINATION_RULE", COMBINATION_RULE);
				if (COMBINATION_RULE.equals("multiplication")) RuleEngine.COMBINATION_RULE_ID = 1;
				if (COMBINATION_RULE.equals("maxplus")) RuleEngine.COMBINATION_RULE_ID = 2;
				if (COMBINATION_RULE.equals("max")) RuleEngine.COMBINATION_RULE_ID = 3;
			}
			*/
			else {
				System.err.println("The prediction type " + PREDICTION_TYPE + " is not yet supported.");
				System.exit(1);
			}

		}
		catch (IOException ex) {
			System.err.println("Could not read relevant parameters from the config file " + CONFIG_FILE);
			ex.printStackTrace();
			System.exit(1);
		}
		
		finally {
			if (input != null) {
				try {
					input.close();
				}
				catch (IOException e) {
					e.printStackTrace();
					System.exit(1);
				}
			}
		}
		
		if (PREDICTION_TYPE.equals("aRx")) {
			

			
			int[] values = getMultiProcessing(PATH_RULES);
			
			PrintWriter log = null;
			if (values[0] == 0) log = new PrintWriter(PATH_RULES + "_plog");
			else log = new PrintWriter(PATH_OUTPUT.replace("|", "") + "_plog");
			log.println("Logfile");
			log.println("~~~~~~~\n");
			log.println();
			log.println(IOHelper.getParams());
			log.flush();
			
			for (int value : values) {
				
				long startTime = System.currentTimeMillis();
				
				// long indexStartTime = System.currentTimeMillis();
				String path_output_used = null;
				String path_rules_used = null;
				if (value == 0) {
					path_output_used = PATH_OUTPUT;
					path_rules_used = PATH_RULES;
				}
				if (value > 0) {
					path_output_used = PATH_OUTPUT.replaceFirst("\\|.*\\|", "" + value);
					path_rules_used = PATH_RULES.replaceFirst("\\|.*\\|", "" + value);
					
				}
				log.println("rules:   " + path_rules_used);
				log.println("output: " + path_output_used);
				log.flush();
			
				

				

				
				PrintWriter pw = new PrintWriter(new File(path_output_used));
				
				TripleSet trainingSet = new TripleSet(PATH_TRAINING);
				TripleSet testSet = new TripleSet(PATH_TEST);
				TripleSet validSet = new TripleSet(PATH_VALID);
				
				RuleReader rr = new RuleReader();
				LinkedList<Rule> rules = rr.read(path_rules_used);
				/*
				ArrayList<Rule> rules = new ArrayList<Rule>();
				 
				if (FILTER) {
					rules = RuleFilter.filter(rulesBefore, log);
				}
				else {
					rules = rulesBefore;
				}
				*/
				System.out.println("* read rules " + rules.size() + " from file");
				// showRulesStats(rules);
				//System.out.println("* loaded rules = " + rulesBefore.size());
				// showRulesStats(rulesBefore);
				
				
				int rulesSize = rules.size();
				RuleEngine.applyRulesARX(rules, testSet, trainingSet, validSet, TOP_K_OUTPUT, pw);
			
			
				long endTime = System.currentTimeMillis();
				System.out.println("* evaluated " + rulesSize + " rules to propose candiates for " + testSet.getTriples().size() + "*2 completion tasks");
				System.out.println("* finished in " + (endTime - startTime) + "ms.");
				
				
				System.out.println();
				
				log.println("finished in " + (endTime - startTime) / 1000 + "s.");
				log.println();
				log.flush();
			}
			log.close();
		}
		/*
		if (PREDICTION_TYPE.equals("xRy")) {
		
			
			TripleSet trainingSet = new TripleSet(PATH_TRAINING);
			TripleSet testSet = new TripleSet(PATH_TEST);
			TripleSet validSet = new TripleSet(PATH_VALID);
			
			RuleReader rr = new RuleReader();
			List<Rule> rules = rr.read(PATH_RULES);
			long startTime = System.currentTimeMillis();
			RuleEngine.applyRulesXRY(rules, testSet, trainingSet, validSet, TOP_K_OUTPUT);
		
		
			long endTime = System.currentTimeMillis();
			System.out.println("* evaluated " + rules.size() + " rules to propose candiates for pairwise completion tasks");
			System.out.println("* finished in " + (endTime - startTime) + "ms.");
		}
		*/

		
	
	}

	
	private static void showRulesStats(List<Rule> rules) { 
		int xyCounter = 0;
		int xCounter = 0;
		int yCounter = 0;
		for (Rule rule : rules) {
			if (rule.isXYRule()) xyCounter++;
			if (rule.isXRule()) xCounter++;
			if (rule.isYRule()) yCounter++;
		}
		System.out.println("XY=" + xyCounter + " X="+ xCounter + " Y=" + yCounter);
		
	}

	private static int[] getMultiProcessing(String path1) {
		String token[] = path1.split("\\|");
		if (token.length < 2) {
			return new int[] {0};
		}
		else {
			String numbers[] = token[1].split(",");
			int[] result = new int[numbers.length];
			int i = 0;
			for (String n : numbers) {
				result[i] = Integer.parseInt(n);
				i++;
			}
			return result;
		}
	}
	

		

}
