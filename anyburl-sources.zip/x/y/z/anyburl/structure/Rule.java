package x.y.z.anyburl.structure;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import x.y.z.anyburl.Apply;
import x.y.z.anyburl.Learn;
import x.y.z.anyburl.data.SampledPairedResultSet;
import x.y.z.anyburl.data.Triple;
import x.y.z.anyburl.data.TripleSet;
import x.y.z.anyburl.io.RuleReader;

public class Rule {
	
	// private static ClopperPearsonInterval cpi = new ClopperPearsonInterval();
	// private double appliedConfidence = -1.0;
	
	Atom head;
	ArrayList<Atom> body; 
	
	private int hashcode = 0;
	private boolean hashcodeInitialized = false;
	
	// scores
	
	// counted in terms of head groundings
	private int predicted = 0;
	private int correctlyPredicted = 0;
	private double confidence = 0.0; 
	
	private static boolean APPLICATION_MODE = false;
	

	
	

	
	
	private static final String[] variables = new String[] {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P"};
	
	private int nextFreeVariable = 0;
	
	public Rule(Atom head) {
		this.head = head;
		this.body = new ArrayList<Atom>();
	}
	
	
	public Rule() {
		this.body = new ArrayList<Atom>();
	}
	
	public static void applicationMode() {
		Rule.APPLICATION_MODE = true;
	}
	

	public void setHead(Atom head) {
		this.head = head;
		
	}
	

	public void addBodyAtom(Atom atom) {
		this.body.add(atom);
		
	}
	
	

	
	public Rule(Path p) {
		this.body = new ArrayList<Atom>();
		if (p.markers[0] == '+') {
			this.head = new Atom(p.nodes[0], p.nodes[1], p.nodes[2], true, true);
		}
		else {
			this.head = new Atom(p.nodes[2], p.nodes[1], p.nodes[0], true, true);
		}
	
		for (int i = 1; i < p.markers.length; i++) {
			if (p.markers[i] == '+') {
				// System.out.println("markers size = " + p.markers.length + "   nodes size = " + p.nodes.length + "   i =" +  i);
				this.body.add(new Atom(p.nodes[i*2], p.nodes[i*2+1], p.nodes[i*2+2], true, true));
			}
			else {
				this.body.add(new Atom(p.nodes[i*2+2], p.nodes[i*2+1], p.nodes[i*2], true, true));
			}			
		}
	}
	
	
	public Rule(int predicted, int correctlyPredicted, double confidence) {
		this.predicted = predicted;
		this.correctlyPredicted = correctlyPredicted;
		this.confidence = confidence; 
		this.body = new ArrayList<Atom>();
	}
	


	public int getPredicted() {
		return this.predicted;
	}
	
	public int getCorrectlyPredicted() {
		return this.correctlyPredicted;
	}


	public double getConfidence() {
		return confidence;
	}
	
	public HashSet<Rule> getGeneralizations(boolean onlyXY) {
		HashSet<Rule> generalizations = new HashSet<>();
		// cyclic rule
		Rule leftright = this.getLeftRightGeneralization();
		if (leftright != null) {
			leftright.replaceAllConstantsByVariables();
			generalizations.add(leftright);
		}	
		if (onlyXY) return generalizations;
		// acyclic rule
		Rule left = this.getLeftGeneralization();
		if (left != null) {
			Rule leftFree = left.createCopy();
			if (leftright == null) leftFree.replaceAllConstantsByVariables();
			left.replaceNearlyAllConstantsByVariables();
			generalizations.add(left);
			if (leftright == null) generalizations.add(leftFree);
			// return generalizations;
		}
		Rule right = this.getRightGeneralization();
		if (right != null) {	
			Rule rightFree = right.createCopy();
			if (leftright == null) rightFree.replaceAllConstantsByVariables();
			right.replaceNearlyAllConstantsByVariables();
			generalizations.add(right);
			if (leftright == null) generalizations.add(rightFree);
			// return generalizations;
		}
		return generalizations;
		
	}
	

	

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(this.predicted + "\t");
		sb.append(this.correctlyPredicted + "\t");
		sb.append(this.confidence + "\t");
		sb.append(this.head);
		sb.append(" <= ");
		for (int i = 0; i < this.body.size()-1; i++) {
			sb.append(this.body.get(i));
			sb.append(", ");
		}
		sb.append(this.body.get(this.body.size() -1));
		return sb.toString();
	}
	
	public boolean equals(Object thatObject) {
		if (thatObject instanceof Rule) {
			Rule that = (Rule)thatObject;
			if (this.head.equals(that.head)) {
				if (this.body.size() == that.body.size()) {
					HashMap<String, String> variablesThis2That = new HashMap<String, String>();
					HashMap<String, String> variablesThat2This = new HashMap<String, String>();
					for (int i = 0; i < this.body.size(); i++) { 
						Atom atom1 = this.body.get(i);
						Atom atom2 = that.body.get(i);
						if (!atom1.getRelation().equals(atom2.getRelation())) {
							return false;
						}
						else {
							if (!checkValuesAndVariables(variablesThis2That, variablesThat2This, atom1, atom2, true)) return false;
							if (!checkValuesAndVariables(variablesThis2That, variablesThat2This, atom1, atom2, false)) return false;
						}
					}
					return true;
				}

			}
			
		}
		return false;
	}
	
	public int hashCode() {
		if (!this.hashcodeInitialized) {
			StringBuffer sb = new StringBuffer(this.head.toString());
			for (Atom atom : this.body) {
				sb.append(atom.getRelation());
			}
			this.hashcode = sb.toString().hashCode();
			this.hashcodeInitialized = true;
		}
		return this.hashcode;
	}
	
	
	
	public void computeScores(TripleSet triples) {
		if (this.isXYRule()) {
			// X is given in first body atom
			SampledPairedResultSet xypairs;
			if (this.body.contains("X")) {
				xypairs = groundBodyCyclic("X", "Y", triples);
			}
			else {
				xypairs = groundBodyCyclic("Y", "X", triples);
			}
			// body groundings		
			int correctlyPredicted = 0;
			int predicted = 0;
			for (String key : xypairs.getValues().keySet()) {
				for (String value : xypairs.getValues().get(key)) {
					predicted++;
					if (triples.isTrue(key, this.head.getRelation(), value)) correctlyPredicted++;
				}
			}
			this.predicted = predicted;
			this.correctlyPredicted = correctlyPredicted;
			this.confidence = (double)correctlyPredicted / (double)predicted;
		}
		if (this.isXRule()) {
			HashSet<String> xvalues = new HashSet<String>();
			computeValuesReversed("X", xvalues, triples);
			int predicted = 0, correctlyPredicted = 0;
			for (String xvalue : xvalues) {
				predicted++;
				if (triples.isTrue(xvalue, this.head.getRelation(), this.head.getRight())) correctlyPredicted++;
			}
			this.predicted = predicted;
			this.correctlyPredicted = correctlyPredicted;
			this.confidence = (double)correctlyPredicted / (double)predicted;
		}
		if (this.isYRule()) {
			HashSet<String> yvalues = new HashSet<String>();
			computeValuesReversed("Y", yvalues, triples);
			int predicted = 0, correctlyPredicted = 0;
			for (String yvalue : yvalues) {
				predicted++;
				if (triples.isTrue(this.head.getLeft(), this.head.getRelation(), yvalue)) correctlyPredicted++;
			}
			this.predicted = predicted;
			this.correctlyPredicted = correctlyPredicted;
			this.confidence = (double)correctlyPredicted / (double)predicted;
		}
	}
	
	
	public boolean isPredicted(String leftValue, String rightValue, TripleSet ts) {
		if (this.isXRule()) {
			if (rightValue.equals(this.head.getRight())) {
				return isBodyTrueAcyclic("X", leftValue, 0, ts);
			}
			return false;
		}
		if (this.isYRule()) {
			if (leftValue.equals(this.head.getLeft())) {
				return isBodyTrueAcyclic("Y", rightValue, 0, ts);
			}
			return false;
		}
		if (this.isXYRule()) {
			throw new RuntimeException("calling the isPredicted method on XY rules is not supported due to its inefficiency");
		}
		return false;
	}
	
	/**
	*  Returns the tail results of applying this rule to a given head value.
	* 
	* @param head The given head value.
	* @param ts The triple set used for computing the results.
	* @return An empty set, a set with one value (the constant of the rule) or the set of all body instantiations.
	*/
	public HashSet<String> computeTailResults(String head, TripleSet ts) {
		HashSet<String> resultSet = new HashSet<String>();
		
		if (this.isXRule()) {
			if (isBodyTrueAcyclic("X", head, 0, ts)) {
				resultSet.add(this.head.getRight());
				return resultSet;
			}
		}
		else if(this.isYRule()) {
			if (this.head.getLeft().equals(head)) {
				computeValuesReversed("Y", resultSet, ts);
				return resultSet;
			}
		}
		else if (this.isXYRule()) {
			
			// Learn.takeTime();
			if (this.body.size() > 3) return resultSet;
			HashSet<String> results = new HashSet<String>();
			Counter count = new Counter();
			// curr , last
			if (this.body.get(0).contains("X")) {
				this.getCyclic("X", "Y", head, 0, true, ts,  new HashSet<String>(), results, count);
			}
			else {
				this.getCyclic("X", "Y", head, this.bodysize() - 1, false, ts,  new HashSet<String>(), results, count);
			}
			// Learn.showElapsedMoreThan(100, "RULE: " + this);
			return results;
			
		}
		return resultSet;
	}
	
	
	/**
	*  Returns the head results of applying this rule to a given tail value.
	* 
	* @param tail The given tail value.
	* @param ts The triple set used for computing the results.
	* @return An empty set, a set with one value (the constant of the rule) or the set of all body instantiations.
	*/
	public HashSet<String> computeHeadResults(String tail, TripleSet ts) {
		HashSet<String> resultSet = new HashSet<String>();
		
		if (this.isYRule()) {
			if (isBodyTrueAcyclic("Y", tail, 0, ts)) {
				resultSet.add(this.head.getLeft());
				return resultSet;
			}
		}
		else if (this.isXRule()) {
			if (this.head.getRight().equals(tail)) {
				computeValuesReversed("X", resultSet, ts);	
				return resultSet;
			}
		}
		else if (this.isXYRule()) {
			if (this.body.size() > 3) return resultSet;
			// Learn.takeTime();
			HashSet<String> results = new HashSet<String>();
			Counter count = new Counter();
			if (this.body.get(0).contains("Y")) {
				this.getCyclic("Y", "X", tail, 0, true, ts,  new HashSet<String>(), results, count);
			}
			else {
				this.getCyclic("Y", "X", tail, this.bodysize() - 1, false, ts,  new HashSet<String>(), results, count);
			}
			
			//Learn.showElapsedMoreThan(100, "RULE: " + this);
			return results;
			
		}
		return resultSet;
	}
	
	
	private SampledPairedResultSet groundBodyCyclic(String firstVariable, String lastVariable, TripleSet triples) {
		return groundBodyCyclic(firstVariable, lastVariable, triples, true);
	}
	
	private SampledPairedResultSet groundBodyCyclic(String firstVariable, String lastVariable, TripleSet triples, boolean samplingOn) {
		SampledPairedResultSet groundings = new SampledPairedResultSet();
		Atom atom = this.body.get(0);
		boolean headNotTail = atom.getLeft().equals(firstVariable);
		ArrayList<Triple> rtriples = triples.getTriplesByRelation(atom.getRelation());
		int counter = 0;
		Counter count = new Counter();
		for (Triple t : rtriples) {
			counter++;
			HashSet<String> lastVariableGroundings = new HashSet<String>();
			// Learn.takeTime();
		
			getCyclic(firstVariable, lastVariable, t.getValue(headNotTail), 0, true, triples, new HashSet<String>(), lastVariableGroundings, count);
			
			// Learn.showElapsedMoreThan(500, "call to getCyclic");
			
			if (lastVariableGroundings.size() > 0) {
				if (firstVariable.equals("X")) {
					groundings.addKey(t.getValue(headNotTail));
					for (String lastVariableValue : lastVariableGroundings) {
						groundings.addValue(lastVariableValue);
					}
				}
				else {
					for (String lastVariableValue : lastVariableGroundings) {
						groundings.addKey(lastVariableValue);
						groundings.addValue(t.getValue(headNotTail));
						
					}
				}
				
			}
			if ((counter >  Learn.SAMPLE_SIZE || groundings.size() > Learn.SAMPLE_SIZE) && samplingOn) {
				break;
			}
			if (!Rule.APPLICATION_MODE && count.get() >= Learn.TRIAL_SIZE) break;
		}
		return groundings;
	}
	
	
	private void getCyclic(String currentVariable, String lastVariable, String value, int bodyIndex, boolean direction, TripleSet triples, HashSet<String> previousValues, HashSet<String> finalResults, Counter count) {
		// System.out.println("currentVariable=" + currentVariable + " lastVariable=" +  lastVariable + " value=" + value + " bodyIndex=" + bodyIndex);
		if (Rule.APPLICATION_MODE && finalResults.size() >= Apply.DISCRIMINATION_BOUND) {
			finalResults.clear();
			return;
		}
		if (count != null) {
			count.inc();
			if (count.get() >= Learn.TRIAL_SIZE || count.get() >= Apply.TRIAL_SIZE) return;
		}
		if (!Rule.APPLICATION_MODE && finalResults.size() >= Learn.SAMPLE_SIZE) return;
		// check if the value has been seen before as grounding of another variable
		Atom atom = this.body.get(bodyIndex);
		boolean headNotTail = atom.getLeft().equals(currentVariable);
		if (previousValues.contains(value)) return;		
		// the current atom is the last
		if ((direction == true && this.body.size() -1 == bodyIndex) || (direction == false && bodyIndex == 0)) {
			// get groundings
			for (String v : triples.getEntities(atom.getRelation(), value, headNotTail)) {
				if (!previousValues.contains(v)) finalResults.add(v);
				// System.out.println("FINAL -> atom.getRelation()=" + atom.getRelation() + " value=" + value + " headNotTail=" + headNotTail);
			}
			return;
		}
		// the current atom is not the last
		else {
			Set<String> results = triples.getEntities(atom.getRelation(), value, headNotTail);
			// System.out.println("atom.getRelation()=" + atom.getRelation() + " value=" + value + " headNotTail=" + headNotTail);
			String nextVariable = headNotTail ? atom.getRight() : atom.getLeft();
			HashSet<String> currentValues = new HashSet<String>();
			currentValues.addAll(previousValues);
			currentValues.add(value);
			int i = 0;
			for (String nextValue : results) {
				if (!Rule.APPLICATION_MODE && i >= Learn.SAMPLE_SIZE) break;
				int updatedBodyIndex = (direction) ? bodyIndex + 1 : bodyIndex - 1;
				getCyclic(nextVariable, lastVariable, nextValue, updatedBodyIndex, direction, triples, currentValues, finalResults, count);
				i++;
			}
			return;
		}
	}


	
	private boolean isBodyTrueAcyclic(String variable, String value, int bodyIndex, TripleSet triples) {
		Atom atom = this.body.get(bodyIndex);
		boolean headNotTail = atom.getLeft().equals(variable);
		// the current atom is the last
		if (this.body.size() -1 == bodyIndex) {
			boolean constant = headNotTail ? atom.isRightC() : atom.isLeftC();
			// get groundings
			// fixed by a constant
			if (constant) {
				String constantValue = headNotTail ? atom.getRight() : atom.getLeft();
				if (headNotTail) {
					return triples.isTrue(value, atom.getRelation(), constantValue);
				}
				else {
					return triples.isTrue(constantValue, atom.getRelation(),value);
				}
			}
			// existential quantification
			else {
				Set<String> results = triples.getEntities(atom.getRelation(), value, headNotTail);
				if (results.size() > 0) return true;
			}
			return false;
		}
		// the current atom is not the last
		else {
			Set<String> results = triples.getEntities(atom.getRelation(), value, headNotTail);
			String nextVariable = headNotTail ? atom.getRight() : atom.getLeft();
			for (String nextValue : results) {
				if (isBodyTrueAcyclic(nextVariable, nextValue, bodyIndex+1, triples)) {
					return true;
				}
			}
			return false;
		}
		// return false;
	}	
	
	
	public boolean isXYRule() {
		if (!this.head.isLeftC() && !this.head.isRightC()) return true;
		else return false;
	}
	
	public boolean isXRule() {
		if (this.isXYRule()) return false;
		else {
			if (!this.head.isLeftC()) return true;
			else return false;
		}
	}
	
	public boolean isYRule() {
		if (this.isXYRule()) return false;
		else {
			if (!this.head.isRightC()) return true;
			else return false;
		}
	}
	

	// **************************
	// *** PRIVATE PLAYGROUND ***
	// **************************

	
	private void replaceNearlyAllConstantsByVariables() {
		int counter = 0;
		for (Atom atom : body) {
			counter++;
			if (counter == body.size()) break;
			if (atom.isLeftC()) {
				String c = atom.getLeft();
				this.replaceByVariable(c, Rule.variables[this.nextFreeVariable]);
				this.nextFreeVariable++;
			}
			if (atom.isRightC()) {
				String c = atom.getRight();
				this.replaceByVariable(c, Rule.variables[this.nextFreeVariable]);
				this.nextFreeVariable++;
			}
		}
	}


	private void replaceAllConstantsByVariables() {
		for (Atom atom : body) {
			if (atom.isLeftC()) {
				String c = atom.getLeft();
				this.replaceByVariable(c, Rule.variables[this.nextFreeVariable]);
				this.nextFreeVariable++;
			}
			if (atom.isRightC()) {
				String c = atom.getRight();
				this.replaceByVariable(c, Rule.variables[this.nextFreeVariable]);
				this.nextFreeVariable++;
			}
		}
	}

	
	private Rule getLeftGeneralization() {
		Rule leftG = this.createCopy();
		String leftConstant = leftG.head.getLeft();
		int xcount = leftG.replaceByVariable(leftConstant, "X");
		if (xcount < 2) leftG = null;
		return leftG;
	}
	
	private Rule getRightGeneralization() {
		Rule rightG = this.createCopy();
		String rightConstant = rightG.head.getRight();
		int ycount = rightG.replaceByVariable(rightConstant, "Y");
		if (ycount < 2) rightG = null;
		return rightG;
	}
	
	private Rule getLeftRightGeneralization() {
		Rule lrG = this.createCopy();
		String leftConstant = lrG.head.getLeft();
		int xcount = lrG.replaceByVariable(leftConstant, "X");
		String rightConstant = lrG.head.getRight();
		int ycount = lrG.replaceByVariable(rightConstant, "Y");
		if (xcount < 2 || ycount < 2) lrG = null;
		return lrG;
	}
	
	
	private Rule createCopy() {
		Rule copy = new Rule(this.head.createCopy());
		for (Atom bodyLiteral : this.body) {
			copy.body.add(bodyLiteral.createCopy());
		}
		copy.nextFreeVariable = this.nextFreeVariable;
		return copy;
	}
	
	private int replaceByVariable(String constant, String variable) {
		int count = this.head.replaceByVariable(constant, variable);
		for (Atom batom : this.body) {
			int bcount = batom.replaceByVariable(constant, variable);
			count += bcount;		
		}
		return count;
	}
	
	private boolean checkValuesAndVariables(HashMap<String, String> variablesThis2That, HashMap<String, String> variablesThat2This, Atom atom1, Atom atom2, boolean leftNotRight) {
		if (atom1.isLRC(leftNotRight) && atom2.isLRC(leftNotRight)) {
			if (!atom1.getLR(leftNotRight).equals(atom2.getLR(leftNotRight))) {
				// different constants in same position
				return false;
			}
		}
		if (atom1.isLRC(leftNotRight) != atom2.isLRC(leftNotRight)) {
			// one varaible and one constants do not fit
			return false;
		}
		if (!atom1.isLRC(leftNotRight) && !atom2.isLRC(leftNotRight)) {
			// special cases X must be at same poistion as X, Y at same as Y
			if (atom1.getLR(leftNotRight).equals("X") && !atom2.getLR(leftNotRight).equals("X")) return false;
			if (atom2.getLR(leftNotRight).equals("X") && !atom1.getLR(leftNotRight).equals("X")) return false;
			
			if (atom1.getLR(leftNotRight).equals("Y") && !atom2.getLR(leftNotRight).equals("Y")) return false;
			if (atom2.getLR(leftNotRight).equals("Y") && !atom1.getLR(leftNotRight).equals("Y")) return false;
			
			if (variablesThis2That.containsKey(atom1.getLR(leftNotRight))) {
				String thatV = variablesThis2That.get(atom1.getLR(leftNotRight));
				if (!atom2.getLR(leftNotRight).equals(thatV)) return false;
			}
			if (variablesThat2This.containsKey(atom2.getLR(leftNotRight))) {
				String thisV = variablesThat2This.get(atom2.getLR(leftNotRight));
				if (!atom1.getLR(leftNotRight).equals(thisV)) return false;
			}
			if (!variablesThis2That.containsKey(atom1.getLR(leftNotRight))) {
				variablesThis2That.put(atom1.getLR(leftNotRight), atom2.getLR(leftNotRight));
				variablesThat2This.put(atom2.getLR(leftNotRight), atom1.getLR(leftNotRight));
			}
		}
		return true;
	}


	public String getTargetRelation() {
		return this.head.getRelation();
	}
	
	// **************************************************************
	// ******************* RETRY ************************************
	// **************************************************************
	
	
	public void computeValuesReversed(String targetVariable, HashSet<String> targetValues, TripleSet ts) {
		int atomIndex = this.body.size() - 1;
		Atom lastAtom = this.body.get(atomIndex);
		String unboundVariable = this.getUnboundVariable();
		if (unboundVariable == null) {
			boolean nextVarIsLeft;
			if (lastAtom.isLeftC()) nextVarIsLeft = false;
			else nextVarIsLeft = true;
			String constant = lastAtom.getLR(!nextVarIsLeft);
			String nextVariable = lastAtom.getLR(nextVarIsLeft);
			Set<String> values = ts.getEntities(lastAtom.getRelation(), constant, !nextVarIsLeft);
			HashSet<String> previousValues = new HashSet<String>();
			previousValues.add(constant);
			for (String value : values) {
				forwardReversed(nextVariable, value, atomIndex-1, targetVariable, targetValues, ts, previousValues);
				if (!Rule.APPLICATION_MODE && targetValues.size() >= Learn.SAMPLE_SIZE) return;
				
				if (Rule.APPLICATION_MODE && targetValues.size() >= Apply.DISCRIMINATION_BOUND) {
					targetValues.clear();
					return;
				}
				
			}
		}
		else {
			boolean nextVarIsLeft;
			if (lastAtom.getLeft().equals(unboundVariable)) nextVarIsLeft = false;
			else nextVarIsLeft = true;
			String nextVariable = lastAtom.getLR(nextVarIsLeft);
			ArrayList<Triple> triples = ts.getTriplesByRelation(lastAtom.getRelation());
			for (Triple t : triples) {
				String value = t.getValue(nextVarIsLeft);
				HashSet<String> previousValues = new HashSet<String>();
				String previousValue = t.getValue(!nextVarIsLeft);
				previousValues.add(previousValue);
				forwardReversed(nextVariable, value, atomIndex-1, targetVariable, targetValues, ts, previousValues);
				if (!Rule.APPLICATION_MODE && targetValues.size() >= Learn.SAMPLE_SIZE) return;
				
				if (Rule.APPLICATION_MODE && targetValues.size() >= Apply.DISCRIMINATION_BOUND) {
					targetValues.clear();
					return;
				}
				
			}
		}
	}
	
	
	
	
	private void forwardReversed(String variable, String value, int bodyIndex, String targetVariable, HashSet<String> targetValues, TripleSet ts, HashSet<String> previousValues) {
		if (previousValues.contains(value)) return;
		if (bodyIndex < 0) {
			targetValues.add(value);
		}
		else {
			HashSet<String> currentValues = new HashSet<String>();
			currentValues.add(value);
			Atom atom = this.body.get(bodyIndex);
			boolean nextVarIsLeft = false;
			if (atom.getLeft().equals(variable)) nextVarIsLeft = false;
			else nextVarIsLeft = true;
			String nextVariable = atom.getLR(nextVarIsLeft);
			HashSet<String> nextValues = new HashSet<String>();			
			if (!Rule.APPLICATION_MODE && targetValues.size() >= Learn.SAMPLE_SIZE) return;
			nextValues.addAll(ts.getEntities(atom.getRelation(), value, !nextVarIsLeft));
			for (String nextValue : nextValues) {
				forwardReversed(nextVariable, nextValue, bodyIndex-1, targetVariable, targetValues, ts, currentValues);
			}
		}
	}
	
	

	private String getUnboundVariable() {
		if (this.body.get(this.body.size()-1).isLeftC() || this.body.get(this.body.size()-1).isRightC()) return null;
		HashMap<String, Integer> counter = new HashMap<String, Integer>();
		for (Atom atom : this.body) {
			if (!atom.getLeft().equals("X") && !atom.getLeft().equals("Y")) {
				if (counter.containsKey(atom.getLeft())) counter.put(atom.getLeft(), 2);
				else counter.put(atom.getLeft(), 1);
			}
			if (!atom.getRight().equals("X") && !atom.getRight().equals("Y")) {
				if (counter.containsKey(atom.getRight())) counter.put(atom.getRight(), 2);
				else counter.put(atom.getRight(), 1);
			}
		}
		for (String variable : counter.keySet()) {
			if (counter.get(variable) == 1) {
				return variable;
			}
		}
		return null;
	}


	public int bodysize() {
		return this.body.size();
	}


	public boolean hasConstantInBody() {
		if (this.body.get(this.body.size()-1).isLeftC() || this.body.get(this.body.size()-1).isRightC()) return true;
		return false;
	}


	public double getAppliedConfidence() {
		// int degree_of_freedom = 0;
		/*
		degree_of_freedom += this.bodysize();
		if (!this.isXYRule()) degree_of_freedom++;
		if (this.hasConstantInBody()) degree_of_freedom++;
		*/
		double prob = (double)this.getCorrectlyPredicted() / ((double)this.getPredicted() + Apply.UNSEEN_NEGATIVE_EXAMPLES);
		return prob;
	}
	
	// *********************************************
	// ***** ENTAILMENT AND RELATED STUFF **********
	// *********************************************
	
	
	/**
	 * 
	 * Checks if this rule is more special than a given rule.
	 * 
	 * @param generalRule The rule that might be more general than this rule.
	 * 
	 * @return True if this rule is more special than the given rule.
	 * 
	 */
	public boolean moreSpecial(Rule g) {
		if (this.head.getRelation().equals(g.head.getRelation())) {
			if (this.head.equals(g.head)) {
				if (g.bodysize() == this.bodysize()) {
					// treat this case, which holds only if the more general has no constant in last position
					int bIndex = 0;
					for (bIndex = 0; bIndex < g.bodysize() - 1; bIndex++) {
						if (!g.body.get(bIndex).equals(this.body.get(bIndex))) {
							return false;
						}
					}
					bIndex = g.bodysize()-1;
					if (this.body.get(bIndex).moreSpecial(g.body.get(bIndex))) {
						return true;
					}	
				}
				else if (g.bodysize() < this.bodysize()) {
					// treat this case, which holds only if the more general has no constant in last position
					int bIndex = 0;
					for (bIndex = 0; bIndex < g.bodysize(); bIndex++) {
						if (!g.body.get(bIndex).equals(this.body.get(bIndex))) {
							return false;
						}
					}
					return true;
				}
				else if (g.bodysize() > this.bodysize()) {
					return false;
				}				
			}
			else {
				// a special case here still needs to be taken care off
				return false;
			}
			
		}
		return false;
		
	}
	
	public static void main(String[] args) throws IOException {
		
		RuleReader rr = new RuleReader();
		List<Rule> rules = rr.read("exp/powerslave/FB15-237/quick-100");
		// List<Rule> rules = new ArrayList<Rule>();
		System.out.println("loaded " + rules.size() + " rules");

		
		for (int i = 0; i < rules.size() - 1; i++) {
			for (int j = i+1; j < rules.size(); j++) {
				Rule ri = rules.get(i);
				Rule rj = rules.get(j);
				if (ri.moreSpecial(rj)) {
					// System.out.println("first is more special than second and more special is less");
					if (ri.getAppliedConfidence() < rj.getAppliedConfidence()) {
						System.out.println(ri);
						System.out.println(rj);
						// System.out.println("L=" + ri.body.get(0).isLeftC() + " R=" + ri.body.get(0).isRightC() );
						System.out.println();
					}

				}
				
			}
		}
		
		
		
		
		
		
		
	}


	public boolean isTrivial() {
		if (this.bodysize() == 1) {
			if (this.head.equals(this.body.get(0))) return true;
		}
		return false;
	}




	

	
}
