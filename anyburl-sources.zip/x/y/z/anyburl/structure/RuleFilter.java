package x.y.z.anyburl.structure;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import x.y.z.anyburl.io.RuleReader;

public class RuleFilter {
	
	
	static int countOneElement = 0;
	static int countMoreElemet = 0;
	static int countConst = 0;
	static int countVar = 0;

	public static ArrayList<Rule> filter(List<Rule> ruleList, PrintWriter log) throws IOException {
		System.out.println(">>> removing redundant rules " );
		HashMap<Atom, ArrayList<Rule>> allRules = new HashMap<>();

		for (Rule r1 : ruleList) {
			if (r1.isXRule() || r1.isYRule()) {
				ArrayList<Rule> b = new ArrayList<>();
				allRules.put(r1.head, b);
			}
		}

		for (Rule r1 : ruleList) {
			if (allRules.containsKey(r1.head)) {
				allRules.get(r1.head).add(r1);
			}
		}
		HashMap<Atom, HashSet<Rule>> rulesFiltered = removeConst(allRules);
		ArrayList<Rule> filteredRules = new ArrayList<Rule>();
		for (HashSet<Rule> ruleSet : rulesFiltered.values()) {
			filteredRules.addAll(ruleSet);
		}
		for (Rule r : ruleList) {
			if (r.isXYRule()) {
				filteredRules.add(r);
			}
		}
		System.out.println("* before=" + ruleList.size() + "   after=" + filteredRules.size());
		log.println("filtering: before=" + ruleList.size() + "   after=" + filteredRules.size());
		log.flush();
		
		
		return filteredRules;
	}

	public static HashMap<Atom, HashSet<Rule>> removeConst(HashMap<Atom, ArrayList<Rule>> allRules) {
		HashMap<Atom, HashSet<Rule>> newRules = new HashMap<>();
		int ergOld = 0;
		int ergNew = 0;

		for (Atom h : allRules.keySet()) {
			ergOld += allRules.get(h).size();
			HashSet<Rule> rulesN = new HashSet<>();

			for (int i = 0; i < allRules.get(h).size(); i++) {
				boolean inside = false;
				for (int j = 0; j < allRules.get(h).size(); j++) {
					if (i != j) {
						if (special(allRules.get(h).get(j), allRules.get(h).get(i))) {
							if (allRules.get(h).get(i).bodysize() > 1 && !inside) {
								countMoreElemet++;
							}
							if (allRules.get(h).get(i).bodysize() == 1 && !inside) {
								countOneElement++;
							}
							if (allRules.get(h).get(i).hasConstantInBody()) {
								countConst++;
							} else {
								countVar++;
							}
							inside = true;
							break;
						}
					}
				}
				if (!inside) {
					rulesN.add(allRules.get(h).get(i));
				}
			}
			newRules.put(h, rulesN);
		}

		for (Atom a : newRules.keySet()) {
			ergNew += newRules.get(a).size();
		}
		/*
		System.out.println("�nderungen:");
		System.out.println("einelementig = " + countOneElement);
		System.out.println("mehrelementig = " + countMoreElemet);
		System.out.println();
		System.out.println("�nderungen durch Konstanten:");
		System.out.println(countConst);
		System.out.println();
		System.out.println("�nderungen durch XY-Regeln:");
		System.out.println(countVar);
		System.out.println();
		System.out.println("Ergebnis:");
		System.out.println("alt = " + ergOld);
		System.out.println("neu = " + ergNew);
		*/
		return newRules;
	}

	// r1 soll allgemeiner sein als r2
	
	// r1 is more special than r2
	// z.B. r2: ... <= r(X,A)
	//      r1: ... <= r(X,c)
	public static boolean special(Rule r1, Rule r2) {
		if (r1.bodysize() > r2.bodysize()) {
			return false;
		}

		if (r1.hasConstantInBody()) {
			return false;
		}

		if (r1.getAppliedConfidence() < r2.getAppliedConfidence()) {
			return false;
		}

		if (r1.bodysize() == r2.bodysize()) {
			for (int i = 0; i < r2.bodysize() - 1; i++) {
				if (!r1.body.get(i).equals(r2.body.get(i))) {
					// unterschiedliche Relationen in Body - Letztes Body-Element wird spaeter
					// geprueft
					return false;
				}
			}

			if (r1.body.get(r1.bodysize() - 1).getRelation().equals(r2.body.get(r2.bodysize() - 1).getRelation())) {
				if ((!r1.body.get(r1.bodysize() - 1).getLeft().equals(r2.body.get(r2.bodysize() - 1).getLeft())
						&& !r1.body.get(r1.bodysize() - 1).getRight()
								.equals(r2.body.get(r2.bodysize() - 1).getRight()))) {
					// falsche Signatur in letztem Body
					return false;
				}
			} else if (!r1.body.get(r1.bodysize() - 1).getRelation().equals(r2.body.get(r2.bodysize() - 1).getRelation())) {
				// unterschiedliche Relationen in letztem Body
				return false;
			}
		} else if (r1.bodysize() < r2.bodysize()) {
			for (int i = 0; i < r1.bodysize(); i++) {
				if (!r1.body.get(i).equals(r2.body.get(i))) {
					// unterschiedliche Relationen in Body
					return false;
				}
			}
		}
		// if (r1.isXYRule() || r2.isXYRule()) {
		//	System.out.println("r2 is more special than r1");
		//	System.out.println("r1: " + r1);
		// 	System.out.println("r2: " + r2);
		// }
		return true;
	}

	public static int sameRel(HashSet<Rule> regel) {
		HashSet<String> s1 = new HashSet<>();
		for (Rule r : regel) {
			for (Atom a : r.body) {
				s1.add(a.getRelation());
			}
		}
		return s1.size();
	}

	public static int sameRel(ArrayList<Rule> regel) {
		HashSet<String> s1 = new HashSet<>();
		for (int i = 0; i < regel.size(); i++) {
			for (Atom a : regel.get(i).body) {
				s1.add(a.getRelation());
			}
		}
		return s1.size();
	}

	public static boolean zweierRegel(ArrayList<Rule> regel) {
		for (int i = 0; i < regel.size(); i++) {
			if (regel.get(i).bodysize() > 1) {
				return true;
			}
		}
		return false;
	}

	public static boolean zweierRegel(HashSet<Rule> regel) {
		for (Rule r : regel) {
			if (r.bodysize() > 1) {
				return true;
			}
		}
		return false;
	}
}