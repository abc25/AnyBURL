package x.y.z.anyburl.structure;

import java.util.LinkedHashMap;

public class LinkedHashMapK {
	
	public LinkedHashMap<String, Double> linkedMap;
	public Integer counter;
	
	public LinkedHashMapK(LinkedHashMap<String, Double> linkedMap, Integer counter) {
		this.linkedMap = linkedMap;
		this.counter = counter;
	}

}
