package x.y.z.anyburl.structure;

public class Atom {
	

	private String relation;
	private String left;
	private String right;
	
	private boolean leftC;
	private boolean rightC;
	
	private int hashcode = 0; 
	private boolean hashcodeInitialized = false;
	
	public Atom(String left, String relation, String right, boolean leftC, boolean rightC) {
		this.left = left;
		this.right = right;
		this.relation = relation;
		this.leftC = leftC;
		this.rightC = rightC;
	}
	
	public Atom(String atomRepresentation) {
		String[] t1 = atomRepresentation.split("\\(", 2);
		String[] t2 = t1[1].split(",");
		String relation = t1[0];
		String left = t2[0];
		String right = t2[1].substring(0, t2[1].length()-1);
		if (right.endsWith(")")) right = right.substring(0, right.length() - 1);
		this.relation = relation;
		this.left = left;
		this.right = right;
		this.leftC = (this.left.length() == 1) ? false : true;
		this.rightC = (this.right.length() == 1) ? false : true;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public String getLeft() {
		return left;
	}

	public void setLeft(String left) {
		this.left = left;
	}

	public String getRight() {
		return right;
	}

	public void setRight(String right) {
		this.right = right;
	}

	public boolean isLeftC() {
		return leftC;
	}

	public void setLeftC(boolean leftC) {
		this.leftC = leftC;
	}

	public boolean isRightC() {
		return rightC;
	}

	public void setRightC(boolean rightC) {
		this.rightC = rightC;
	}

	
	public String toString() {
		return this.relation + "(" + this.left + "," + this.right + ")"; 
	}
	
	// TODO write code
	public boolean equals(Object thatObject) {
		if (thatObject instanceof Atom) {
			Atom that = (Atom)thatObject;
			if (this.getRelation().equals(that.getRelation()) && this.getLeft().equals(that.getLeft()) && this.getRight().equals(that.getRight())) {
				return true;
			}
			
		}
		return false;
	}
	
	// TODO write code
	public boolean moreSpecial(Atom g) {
		if (this.getRelation().equals(g.getRelation())) {			
			if (this.equals(g)) {
				return true;
			}
			
			if (this.left.equals(g.left)) {
				if (!g.rightC && this.rightC) return true;
				return false;
			}
			if (this.right.equals(g.right)) {
				if (!g.leftC && this.leftC) return true;
				return false;
			}
			if (!g.leftC && !g.rightC && this.leftC && this.rightC) return true;
			return false;
		}
		return false;
	}
	
	
	public static void main(String[] args) {
		Atom a1 = new Atom("A", "relation", "B", false, false);
		Atom a2 = new Atom("A", "relation", "b", false, true);
		Atom a3 = new Atom("a", "relation", "B", true, false);
		Atom a4 = new Atom("a", "relation", "b", true, true);
		Atom a5 = new Atom("A", "relation", "c", false, true);		
		
		
		System.out.println(a1.moreSpecial(a2));
		System.out.println(a1.moreSpecial(a3));
		System.out.println(a1.moreSpecial(a4));
		System.out.println("----");
		System.out.println(a2.moreSpecial(a1));
		System.out.println(a2.moreSpecial(a3));
		System.out.println(a2.moreSpecial(a4));
		System.out.println(a2.moreSpecial(a5));
		System.out.println("----");
		System.out.println(a3.moreSpecial(a1));
		System.out.println(a3.moreSpecial(a2));
		System.out.println(a3.moreSpecial(a4));
		System.out.println("----");
		System.out.println(a4.moreSpecial(a1));
		System.out.println(a4.moreSpecial(a2));
		System.out.println(a4.moreSpecial(a3));
		
	}
	
	
	
	
	
	public int hashCode() {
		if (!this.hashcodeInitialized ) {
			this.hashcode = this.toString().hashCode();
			this.hashcodeInitialized = true;
		}
		return this.hashcode;
	}

	public Atom createCopy() {
		Atom copy = new Atom(this.left, this.relation, this.right, this.leftC, this.rightC);
		return copy;
	}

	public int replaceByVariable(String constant, String variable) {
		int i = 0;
		if (this.leftC && this.left.equals(constant)) {
			this.leftC = false;
			this.left = variable;
			i++;
		}
		if (this.rightC && this.right.equals(constant)) {
			this.rightC = false;
			this.right = variable;
			i++;
		}
		return i;
	}

	public boolean uses(String constantOrVariable) {
		if (this.getLeft().equals(constantOrVariable)) {
			return true;
		}
		if (this.getRight().equals(constantOrVariable)) {
			return true;
		}
		return false;
	}

	public boolean isLRC(boolean leftNotRight) {
		if (leftNotRight) return this.isLeftC();
		else return this.isRightC();
	}

	public String getLR(boolean leftNotRight) {
		if (leftNotRight) return this.getLeft();
		else return this.getRight();
	}

	public boolean contains(String term) {
		if (this.left.equals(term) || this.right.equals(term)) return true;
		return false;
	}
	

}
