package x.y.z.anyburl.structure;

public class Counter {
	
	private int i = 0;
	
	public void inc() {
		this.i++;
	}
	
	public int get() {
		return i;
	}

}
