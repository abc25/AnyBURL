package x.y.z.anyburl.structure;

import java.util.Comparator;

import x.y.z.anyburl.Apply;

public class RuleConfidenceComparator implements Comparator<Rule> {


	public int compare(Rule o1, Rule o2) {
		double prob1 = (double)o1.getCorrectlyPredicted() / ((double)o1.getPredicted() + Apply.UNSEEN_NEGATIVE_EXAMPLES);
		double prob2 = (double)o2.getCorrectlyPredicted() / ((double)o2.getPredicted() + Apply.UNSEEN_NEGATIVE_EXAMPLES);
		if (prob1 < prob2) return 1;
		else if (prob1 > prob2) return -1;
		return 0;
	}

}
