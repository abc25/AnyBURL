package x.y.z.anyburl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Properties;

import x.y.z.anyburl.algorithm.PathSampler;
import x.y.z.anyburl.data.TripleSet;
import x.y.z.anyburl.io.IOHelper;
import x.y.z.anyburl.structure.Path;
import x.y.z.anyburl.structure.Rule;

public class Learn {
	
	private static long timeStamp = 0;
	
	private static String CONFIG_FILE = "config-learn.properties";
	
	/**
	 * Path to the file that contains the triple set used for learning the rules.
	 */
	public static String PATH_TRAINING = "";
	
	/**
	 * Path to the output file where the learned rules will be stored.
	 */
	public static String PATH_OUTPUT = "";
	
	
	/**
	 * Takes a snapshot of the rules learned after each time interval specified in seconds.
	 */
	public static int[] SNAPSHOTS_AT = new int[] {10, 60, 300, 600, 1800};
	
	
	
	/**
	 * The maximal number of body atoms in cyclic rules (inclusive this number). If this number is exceeded all computation time
	 * is used for acyclic rules only from that time on.
	 * 
	 */
	public static int MAX_LENGTH_CYCLIC = 2;
	
	
	/**
	* Used for restricting the number of samples drawn for computing scores as confidence.
	*/
	public static int SAMPLE_SIZE = 1000;
	
	
	/**
	* Number of maximal attempts to create body grounding. Every partial body grounding is counted.
	*/
	public static int TRIAL_SIZE = 1000000;

		
	/**
	 * The time that is reserved for one batch in milliseconds. Each second batch is 
	 * used for mining cyclic/acyclic rules. 
	 */
	public static int BATCH_TIME = 500;
	
	
	/**
	 * The saturation required to move to the next rule length. Saturation is defined as the fraction of 
	 * useful rules that have been sampled in a previous batch compared to all useful rules that have
	 * been sampled within that batch. If the saturation is above the value, longer rules are sampled.
	 */
	public static double SATURATION = 0.75;
	
	/**
	 * The threshold for the number of correctly prediction within the given training set.
	 */
	public static int THRESHOLD_CORRECT_PREDICTIONS = 5;

	/**
	 * The threshold for the confidences.
	 */
	public static double THRESHOLD_CONFIDENCE = 0.05;
	
	
	

	public static void main(String[] args) throws FileNotFoundException {
		
		if (args.length == 1) {
			CONFIG_FILE = args[0];
			System.out.println("reading params from file " + CONFIG_FILE);
		}
		
		Properties prop = new Properties();
		InputStream input = null;
		
		try {
			input = new FileInputStream(CONFIG_FILE);
			prop.load(input);
			PATH_TRAINING = IOHelper.getProperty(prop, "PATH_TRAINING",PATH_TRAINING);
			PATH_OUTPUT = IOHelper.getProperty(prop, "PATH_OUTPUT", PATH_OUTPUT);	
			SNAPSHOTS_AT = IOHelper.getProperty(prop, "SNAPSHOTS_AT", SNAPSHOTS_AT);
			SAMPLE_SIZE = IOHelper.getProperty(prop, "SAMPLE_SIZE", SAMPLE_SIZE);
			TRIAL_SIZE = IOHelper.getProperty(prop, "TRIAL_SIZE", TRIAL_SIZE);
			BATCH_TIME = IOHelper.getProperty(prop, "BATCH_TIME", BATCH_TIME);
			SATURATION = IOHelper.getProperty(prop, "SATURATION", SATURATION);
			MAX_LENGTH_CYCLIC = IOHelper.getProperty(prop, "MAX_LENGTH_CYCLIC", MAX_LENGTH_CYCLIC);
			THRESHOLD_CORRECT_PREDICTIONS = IOHelper.getProperty(prop, "THRESHOLD_CORRECT_PREDICTIONS", THRESHOLD_CORRECT_PREDICTIONS);
			THRESHOLD_CONFIDENCE = IOHelper.getProperty(prop, "THRESHOLD_CONFIDENCE", THRESHOLD_CONFIDENCE);
			
		}
		catch (IOException ex) {
			System.err.println("Could not read relevant parameters from the config file " + CONFIG_FILE);
			ex.printStackTrace();
			System.exit(1);
		}
		
		finally {
			if (input != null) {
				try {
					input.close();
				}
				catch (IOException e) {
					e.printStackTrace();
					System.exit(1);
				}
			}
		}
		
		PrintWriter log = new PrintWriter(PATH_OUTPUT + "_log");
		log.println("Logfile");
		log.println("~~~~~~~\n");
		
		long indexStartTime = System.currentTimeMillis();
		
		TripleSet ts = new TripleSet(PATH_TRAINING);
		PathSampler ps = new PathSampler(ts);		
		
		int pathCounter = 0;
		// int batchPathCounter = 0;
		int batchCounter = 0;


		int batchPreviouslyFoundRules = 0;
		int batchNewUsefulRules = 0;
		int batchRules = 0;

		boolean mineCyclicNotAcyclic = false;
		
		ArrayList<HashSet<Rule>> allUsefulRules = new ArrayList<HashSet<Rule>>();
		allUsefulRules.add(new HashSet<Rule>());
		
		
		int snapshotIndex = 0;
		
		int ruleSizeCyclic = 0;
		int ruleSizeAcyclic = 0;
		
		double lastCyclicCoverage = 0.0;
		double lastAcyclicCoverage = 0.0;
		
		long indexEndTime = System.currentTimeMillis();
		log.println("indexing dataset: " + PATH_TRAINING);
		log.println("time elapsed: " + (indexEndTime - indexStartTime) + "ms");
		log.println();
		log.println(IOHelper.getParams());
		log.flush();
		
		long startTime = System.currentTimeMillis();
		
		while (true) {
			int ruleSize = mineCyclicNotAcyclic ? ruleSizeCyclic : ruleSizeAcyclic;
			
			HashSet<Rule> usefulRules = allUsefulRules.get(ruleSize);
			long time = System.currentTimeMillis();
			int elapsedSeconds = (int)(time - startTime) / 1000;
			
			if (elapsedSeconds > SNAPSHOTS_AT[snapshotIndex]) {
				storeRules(PATH_OUTPUT, SNAPSHOTS_AT[snapshotIndex], allUsefulRules, log, lastCyclicCoverage, lastAcyclicCoverage, elapsedSeconds);
				// writeLog(PATH_OUTPUT, SNAPSHOTS_AT[snapshotIndex], allUsefulRules);
				
				
				snapshotIndex++;
				System.out.println("CREATED SNAPSHOT " + snapshotIndex + " after " + elapsedSeconds + " seconds");
				if (snapshotIndex == SNAPSHOTS_AT.length) {
					log.flush();
					log.close();
					System.out.println("Bye, bye");
					System.exit(1);
				}
			}
			long batchStartTime = System.currentTimeMillis();
			long currentTime = 0;
			while (true) {
				//batchPathCounter++;
				currentTime = System.currentTimeMillis();
				if (currentTime- batchStartTime > BATCH_TIME) break;
				pathCounter++;
				// takeTime();
				Path p = ps.samplePath(ruleSize + 2, mineCyclicNotAcyclic);
				if (p != null && p.isValid()) {
					
					// if (mineCyclicNotAcyclic && !p.isCyclic()) continue;
					// if (!mineCyclicNotAcyclic && p.isCyclic()) continue;
					
					Rule pr = new Rule(p);
					HashSet<Rule> rules = pr.getGeneralizations(mineCyclicNotAcyclic);					
					
					
					
					for (Rule r : rules) {
						
						if (r.isTrivial()) continue;
						// if (!mineCyclicNotAcyclic && r.isXYRule()) continue;
						
						batchRules++;
						//if (r.isXYRule()) batchCyclicRules++;
						//else batchAcyclicRules++;
	
						
						if (!usefulRules.contains(r)) {
		
							
							// takeTime();
							r.computeScores(ts);
							//  showElapsedMoreThan(500, "computing cyclic=" + mineCyclicNotAcyclic);
							// if (!r.isXYRule()) continue;
			
							if (r.getConfidence() >= THRESHOLD_CONFIDENCE &&  r.getCorrectlyPredicted() >= THRESHOLD_CORRECT_PREDICTIONS) {
								batchNewUsefulRules++;
								//if (r.isXYRule()) batchNewUsefulCyclicRules++;
								//else batchNewUsefulAcyclicRules++;
								usefulRules.add(r);
								
								
							}
						}
						else {
							batchPreviouslyFoundRules++;
							//if (r.isXYRule()) batchPreviouslyFoundCyclicRules++;
							//else batchPreviouslyFoundAcyclicRules++;
						}

					}
				}
			}
			batchCounter++;
			String type = mineCyclicNotAcyclic ? "CYCLIC" : "ACYCLIC";
			System.out.println(">>> ****** Batch [" + type + " " + (ruleSize+1) +"] " + batchCounter + " (sampled " + pathCounter + " pathes) *****");
			double currentCoverage = batchPreviouslyFoundRules / (double)(batchNewUsefulRules + batchPreviouslyFoundRules);
			//double currentCyclicCoverage = batchPreviouslyFoundCyclicRules / (double)(batchNewUsefulCyclicRules + batchPreviouslyFoundCyclicRules);
			//double currentAcyclicCoverage = batchPreviouslyFoundAcyclicRules / (double)(batchNewUsefulAcyclicRules + batchPreviouslyFoundAcyclicRules);
			
			
			System.out.println(">>> fraction of previously seen rules within useful rules in this batch: " +  currentCoverage + " NEW=" + batchNewUsefulRules + " PREV=" + batchPreviouslyFoundRules + " ALL=" +batchRules);
			// System.out.println(">>> fraction of previously seen cyclic rules within useful rules in this batch: " +  currentCyclicCoverage + " NEW=" + batchNewUsefulCyclicRules + " PREV=" + batchPreviouslyFoundCyclicRules);
			// System.out.println(">>> fraction of previously seen acyclic rules within useful rules in this batch: " +  currentAcyclicCoverage + " NEW=" + batchNewUsefulAcyclicRules + " PREV=" + batchPreviouslyFoundAcyclicRules);
			System.out.println(">>> stored rules: " + usefulRules.size());
			if (mineCyclicNotAcyclic) lastCyclicCoverage = currentCoverage;
			else lastAcyclicCoverage = currentCoverage;
			if (currentCoverage > SATURATION && batchPreviouslyFoundRules > 1) {
				ruleSize++;
				if (mineCyclicNotAcyclic) ruleSizeCyclic = ruleSize;
				if (!mineCyclicNotAcyclic) ruleSizeAcyclic = ruleSize;
				System.out.println(">>> ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ");
				System.out.println(">>> INCREASING RULE SIZE OF " + type + " RULE TO " + (ruleSize + 1));
				System.out.println(">>> ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				log.println("increasing rule size of " + type + " rules to " + (ruleSize + 1) + " after " + ((startTime - System.currentTimeMillis()) / 1000) + "s");
				log.println();
				log.flush();
				allUsefulRules.add(new HashSet<Rule>());
			}
			
			batchNewUsefulRules = 0;
			batchRules = 0;
			batchPreviouslyFoundRules = 0;

			
			mineCyclicNotAcyclic = !mineCyclicNotAcyclic;
			if (mineCyclicNotAcyclic && ruleSizeCyclic + 1 > MAX_LENGTH_CYCLIC) {
				mineCyclicNotAcyclic = false;
			}
		}
		
		
	}

	public static void showElapsedMoreThan(long duration, String message) {
		long now = System.currentTimeMillis();
		long elapsed = now - timeStamp;
		if (elapsed > duration) {
			System.err.println(message + " required " + elapsed + " millis!");
		}
		
	}

	public static void takeTime() {
		timeStamp = System.currentTimeMillis();
		
	}

	private static void storeRules(String path, int snapshotCounter, ArrayList<HashSet<Rule>> rules, PrintWriter log, double lastCC, double lastAC, int elapsedSeconds) {
		DecimalFormat df = new DecimalFormat("###.#");
		File ruleFile = new File(path + "-" + snapshotCounter);
		
		// very dirty
		int maxBodySize = 10;
		int[] acyclicCounter = new int[maxBodySize];
		int[] cyclicCounter = new int[maxBodySize];
		
		try {
			log.println();
			log.println("rule file: " + ruleFile.getPath());
			System.out.println(">>> Storing rules in file " + ruleFile.getPath());
			PrintWriter pw = new PrintWriter(ruleFile);
			for (HashSet<Rule> rrules : rules) {
				for (Rule r : rrules) {
					if (r.bodysize() < maxBodySize)
					if (r.isXYRule()) cyclicCounter[r.bodysize()-1]++;
					else acyclicCounter[r.bodysize()-1]++;
					pw.println(r);
				}
			}
			pw.flush();
			pw.close();
			log.print("cyclic: ");
			for (int i = 0; i< maxBodySize; i++) {
				if (cyclicCounter[i] == 0) break;
				log.print(cyclicCounter[i] + " | ");
			}
			log.println(df.format(lastCC * 100) + "%");
			log.print("acyclic: ");
			for (int i = 0; i< maxBodySize; i++) {
				if (acyclicCounter[i] == 0) break;
				log.print(acyclicCounter[i] + " | ");
			}
			log.println(df.format(lastAC * 100) + "%");
			log.println("time planned: " + snapshotCounter +  "s");
			log.println("time elapsed: " + elapsedSeconds + "s");
			log.println("");
			log.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		
		
	}

}
