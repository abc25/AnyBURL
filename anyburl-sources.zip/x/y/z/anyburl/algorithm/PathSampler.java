package x.y.z.anyburl.algorithm;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

import x.y.z.anyburl.data.Triple;
import x.y.z.anyburl.data.TripleSet;
import x.y.z.anyburl.structure.Path;
import x.y.z.anyburl.structure.Rule;

/**
* This class is responsible for sampling grounded pathes.
*
*/
public class PathSampler {

	private TripleSet ts;
	private Random rand = new Random();
	
	
	public static void main(String[] args) {
		
		TripleSet ts = new TripleSet("E:/coding/eclipse-oxygen-workspace/RuleN18/data/FB15k/train.txt");
		PathSampler ps = new PathSampler(ts);
		
		HashSet<Path> somePathes = new HashSet<Path>();
		
		for (int i = 0; i < 1000; i++) {
			// if (i % 1000 == 0) System.out.println("iteration " + i);
			Path p = ps.samplePath(2, true);
			if (p != null && p.isValid()) {
				somePathes.add(p);
			}

		}
		//somePathes.add(ps.samplePath(2));
		//somePathes.add(ps.samplePath(2));
		//somePathes.add(ps.samplePath(2));
		
		System.out.println();
		System.out.println(" *** Sampled " + somePathes.size() + " valid pathes.");
		System.out.println();
		//System.exit(1);
		
		
		int numOfRules = 0;
		int numOfUsefulRules = 0; 
		int lastUsefulRule = 0;
		int numOfPathes = 0;
		int batchPreviouslyFoundRules = 0;
		int batchUsefulRules = 0;
		int batchRules = 0;
		
		HashSet<Rule> usefulRules = new HashSet<Rule>();
		for (Path p : somePathes) {
			numOfPathes++;
			Rule pr = new Rule(p);
			HashSet<Rule> rules = pr.getGeneralizations(false);
			
			// System.out.println("Path:  " + p);
			// System.out.println("Rule:  " + r);
			// System.out.println("PATH: " + p);
			
			
			for (Rule r : rules) {
				numOfRules++;
				batchRules++;
				r.computeScores(ts);
				double conf = r.getConfidence();
				int bodyGroundings = r.getPredicted();
				
				if (conf > 0.01 && bodyGroundings * conf > 10.001) {
					if (!usefulRules.contains(r)) {
						batchUsefulRules++;
						numOfUsefulRules++;
						//System.out.println("gap=" + (numOfRules - lastUsefulRule));
						//System.out.println(r);
						lastUsefulRule = numOfRules;	
						usefulRules.add(r);
					}
					else {
						batchPreviouslyFoundRules++;
					}
					
				}
				// String cyc = p.isCyclic() ? "[C] ": ""; 
				// System.out.println("\t" + cyc + r);
				
			}
			if (numOfPathes % 1000 == 0) {
				System.out.println("batch fraction = " +  (batchUsefulRules / (double)batchRules));
				System.out.println("previously found within this batch =" + batchPreviouslyFoundRules);
				batchPreviouslyFoundRules = 0;
				batchUsefulRules = 0;
				batchRules = 0;
			}
			
		}
		System.out.println("-----------------------------------");
		System.out.println("numOfRules=" +  numOfRules);
		System.out.println("numOfUsefulRules=" +  numOfUsefulRules);
		
	

		
	}
	
	
	public PathSampler(TripleSet ts) {
		this.ts = ts;
	}
	
	public Path samplePath(int steps, boolean cyclic) {
		String[] nodes = new String[1 + steps * 2];
		char[] markers = new char[steps];
		int dice = this.rand.nextInt(ts.getTriples().size());
		Triple triple = this.ts.getTriples().get(dice);
		// TODO hardcoded test to avoid reflexive relations in the head
		if (triple.getHead().equals(triple.getTail())) return null;
		if (this.rand.nextDouble() < 0.5) {
			markers[0] = '+';
			nodes[0] = triple.getHead();
			nodes[1] = triple.getRelation();
			nodes[2] = triple.getTail();
		}
		else {
			markers[0] = '-';
			nodes[2] = triple.getHead();
			nodes[1] = triple.getRelation();
			nodes[0] = triple.getTail();
		}
		// add next hop
		int index = 1;
		while (index < steps) {
			if (this.rand.nextDouble() < 0.5) {
				ArrayList<Triple> candidateTriples = ts.getTriplesByHead(nodes[index*2]);
				if (candidateTriples.size() == 0) return null;
				Triple nextTriple;
				if (cyclic && index + 1 == steps) {
					ArrayList<Triple> cyclicCandidateTriples = new ArrayList<>();
					for (Triple t : candidateTriples) {
						if (t.getTail().equals(nodes[0])) cyclicCandidateTriples.add(t);
					}
					if (cyclicCandidateTriples.size() == 0) return null;
					nextTriple = cyclicCandidateTriples.get(this.rand.nextInt(cyclicCandidateTriples.size()));
				}
				else {
					nextTriple = candidateTriples.get(this.rand.nextInt(candidateTriples.size()));
				}
				nodes[index*2+1] = nextTriple.getRelation();
				nodes[index*2+2] = nextTriple.getTail();
				markers[index] = '+';
			}
			else {
				ArrayList<Triple> candidateTriples = ts.getTriplesByTail(nodes[index*2]);
				if (candidateTriples.size() == 0) return null;
				Triple nextTriple;
				if (cyclic && index + 1 == steps) {
					ArrayList<Triple> cyclicCandidateTriples = new ArrayList<>();
					for (Triple t : candidateTriples) {
						if (t.getHead().equals(nodes[0])) cyclicCandidateTriples.add(t);
					}
					if (cyclicCandidateTriples.size() == 0) return null;
					nextTriple = candidateTriples.get(this.rand.nextInt(cyclicCandidateTriples.size()));
				}
				else {
					nextTriple = candidateTriples.get(this.rand.nextInt(candidateTriples.size()));
				}
				nodes[index*2+1] = nextTriple.getRelation();
				nodes[index*2+2] = nextTriple.getHead();
				markers[index] = '-';
			}
			index++;
		}
		Path p = new Path(nodes, markers);
		// check if path is valid
		return p;
	}
	

	
}
