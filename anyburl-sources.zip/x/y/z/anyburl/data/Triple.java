package x.y.z.anyburl.data;

/**
 * A triple represents a labeled edge a knowledge graph.
 * 
 *
 */
public class Triple {

	private String head; // subject
	private String tail; // object
	private String relation;
	
	private int h = 0;
	private boolean h_set = false;
	
	public Triple(String head, String relation, String tail) {
		this.head = head;
		this.relation = relation;
		this.tail = tail;
	}
	
	public String getHead() {
		return this.head;
	}

	public String getTail() {
		return this.tail;
	}
	
	public String getValue(boolean headNotTail) {
		if (headNotTail) return this.head;
		else return this.tail;
	}

	public String getRelation() {
		return relation;
	}
	
	public String toString() {
		return this.head + " " + this.relation + " " + this.tail;
	}
	
	public boolean equals(Object that) {
		if (that instanceof Triple || that instanceof AnnotatedTriple) {
			Triple thatTriple = (Triple)that;
			if (this.head.equals(thatTriple.head) && this.tail.equals(thatTriple.tail) && this.relation.equals(thatTriple.relation)) {
				return true;
			}
		}
		return false;
	}
	
	public int hashCode() {
		if (!h_set) {
			h = this.head.hashCode() + this.tail.hashCode() + this.relation.hashCode();
		}	
		return h;
	}


 	

}
