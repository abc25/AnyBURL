package x.y.z.anyburl.eval;

import java.util.ArrayList;

public class CompletionResult {
	
	private ArrayList<String> headResults;
	private ArrayList<String> tailResults;
	
	private String triple;
	
	public CompletionResult(String triple) {
		this.triple = triple;
		this.headResults = new ArrayList<>();
		this.tailResults = new ArrayList<>();
		
	}
	
	public void addHeadResults(String[] heads, int k) {
		if (k > 0) addResults(heads, this.headResults, k);
		else addResults(heads, this.headResults);
		
	}
	


	public void addTailResults(String[] tails, int k) {
		if (k > 0) addResults(tails, this.tailResults, k);
		else addResults(tails, this.tailResults);
	}
	
	
	private void addResults(String[] candidates, ArrayList<String> results, int k) {
		for (String c : candidates) {
			if (!c.equals("")) {
				results.add(c);
				k--;
				if (k == 0) return;
			}
		}	
	}
	
	private void addResults(String[] candidates, ArrayList<String> results) {
		for (String c : candidates) {
			if (!c.equals("")) {
				results.add(c);
			}
		}	
	}

	public ArrayList<String> getHeads() {
		return this.headResults;
	}
	
	public ArrayList<String> getTails() {
		return this.tailResults;
	}
	

}
