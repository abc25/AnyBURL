package x.y.z.anyburl.eval;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;

public class ResultSet {
	
	private HashMap<String, CompletionResult> results;
	private String name;
	
	public static boolean applyThreshold = false;
	public static double threshold = 0.0;
	
	
	
	private boolean containsConfidences = false;
	
	
	public ResultSet(String name, String filePath) {
		this(name, filePath, false, 0);
		
	}
	
	public ResultSet(String name, boolean containsConfidences, int k) {
		this(name, name, containsConfidences, k);
	}
	
	public ResultSet(String name, String filePath, boolean containsConfidences, int k) {
		System.out.println("* loading result set at " +  filePath);
		this.containsConfidences = containsConfidences;
		this.name = name;
		this.results = new HashMap<String, CompletionResult>();
		try {
			File file = new File(filePath);
			// FileReader fileReader = new FileReader(file);
			
			// FileInputStream i = null;
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));
			String tripleLine;
			while ((tripleLine = bufferedReader.readLine()) != null) {
				if (tripleLine.length() < 3) continue;
				CompletionResult cr = new CompletionResult(tripleLine);
				String headLine = bufferedReader.readLine();
				String tailLine = bufferedReader.readLine();
				String tempLine = "";
				if (headLine.startsWith("Tails:")) {
					System.out.println("reversed");
					tempLine = headLine;
					headLine = tailLine;
					tailLine = tempLine;
				}
				if (!applyThreshold) {
					cr.addHeadResults(getResultsFromLine(headLine.substring(7)), k);
					cr.addTailResults(getResultsFromLine(tailLine.substring(7)), k);
				}
				else {
					cr.addHeadResults(getThresholdedResultsFromLine(headLine.substring(7)), k);
					cr.addTailResults(getThresholdedResultsFromLine(tailLine.substring(7)), k);
				}
				this.results.put(tripleLine.split("\t")[0], cr);
			}
			bufferedReader.close();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	private String[] getThresholdedResultsFromLine(String rline) {
		if (!containsConfidences) {
			return rline.split("\t");
		}
		else {
			String t = "";
			String cS = "";
			String[] token = rline.split("\t");
			// String[] tokenx = new String[token.length / 2];
			ArrayList<String> tokenx = new ArrayList<String>();
			for (int i = 0; i < token.length / 2; i++) {
				
				t = token[i*2];
				cS = token[i*2 + 1];
				double c = Double.parseDouble(cS);
				if (c > threshold) {
					tokenx.add(t);
				}
				else {
					break;
				}
			}
			String[] tokenxx = (String[]) tokenx.toArray(new String[0]);
			return tokenxx;
		}
	}
	
	private String[] getResultsFromLine(String rline) {
		if (!containsConfidences) {
			return rline.split("\t");
		}
		else {
			String[] token = rline.split("\t");
			String[] tokenx = new String[token.length / 2];
			for (int i = 0; i < tokenx.length; i++) {
				tokenx[i] = token[i*2];
			}
			return tokenx;
		}
	}

	public ArrayList<String> getHeadCandidates(String triple) {
		try {
			// System.out.println("head: " + triple);
			CompletionResult cr = this.results.get(triple);
			return cr.getHeads();
		}
		catch(RuntimeException e) {
			return new ArrayList<String>();
		}
	}
	
	public ArrayList<String> getTailCandidates(String triple) {
		// System.out.println("tail: " + triple);
		try {
			CompletionResult cr = this.results.get(triple);
			return cr.getTails();
		}
		catch(RuntimeException e) {
			return new ArrayList<String>();
		}
	}

	public String getName() {
		return this.name;
	}

	
	
	
	
	

}
