package x.y.z.anyburl.io;

import x.y.z.anyburl.data.Triple;
import x.y.z.anyburl.data.TripleSet;

public class Test {

	public static void main(String[] args) {
		
		TripleSet trainingSet = new TripleSet("../RuleN18/data/FB15-237/test.txt");
		
		System.out.println(trainingSet.getEntities().size());
		// TripleSet testSet = new TripleSet("../RuleN18/data/FB15-237/test.txt");
		
		/*
		int counter = 0;
		for (Triple test : testSet.getTriples()) {
			String head = test.getHead();
			String tail = test.getTail();
			
			int a = trainingSet.getTriplesByHead(head).size();
			int b = trainingSet.getTriplesByHead(tail).size();
			int c = trainingSet.getTriplesByTail(head).size();
			int d = trainingSet.getTriplesByTail(tail).size();
			
			// System.out.println(a + b + c + d);
			if (a + c == 0 || b+ d == 0) {
				counter++;
				System.out.println(test);
			}
			
			
		}
		System.out.println("unconnected: " + counter + " out of " + testSet.getTriples().size());
		*/

	}

}
