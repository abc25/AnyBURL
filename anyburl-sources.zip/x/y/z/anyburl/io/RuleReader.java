package x.y.z.anyburl.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import x.y.z.anyburl.structure.Atom;
import x.y.z.anyburl.structure.Rule;


public class RuleReader {
	
	public static void main(String[] args) throws IOException {
		RuleReader rr = new RuleReader();
		rr.read("exp/test/firstrun-1.txt");
		
		
	}
	
	/**
	* @param filepath The file to read the rules from.
	* @returnA list of rules.
	* @throws IOException
	*/
	public LinkedList<Rule> read(String filepath) throws IOException {
		LinkedList<Rule> rules = new LinkedList<Rule>();
		HashMap<Long, Rule> ids2Rules = new HashMap<Long,Rule>();
		File file = new File(filepath);
		BufferedReader br = new BufferedReader((new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8)));
		try {
		    String line = br.readLine();
		    while (line != null) {
		        if (line == null || line.equals("")) break;
		        // System.out.println(line);
		        Rule r = this.getRule(line, ids2Rules);
		        if (r != null) {
			        rules.add(r);
		        }
		        line = br.readLine();
		    }
		}
		finally {
		    br.close();
		}
		return rules;
	}
	
	private Rule getRule(String line, HashMap<Long, Rule> id2Rules) {
		if (line.startsWith("#")) return null;
		// System.out.println("line: " +  line);
		String token[] = line.split("\t");
		// System.out.println("#token=" + token.length);
		
		Rule r = new Rule(
				Integer.parseInt(token[0]),
				Integer.parseInt(token[1]),
				Double.parseDouble(token[2])
		);
		
		
		String atomsS[] = token[3].split(" ");
		
		r.setHead(new Atom(atomsS[0]));
		for (int i = 2; i < atomsS.length; i++) {
			r.addBodyAtom(new Atom(atomsS[i]));
		}
		// System.out.println(r);
		return r;
		
	}

}
